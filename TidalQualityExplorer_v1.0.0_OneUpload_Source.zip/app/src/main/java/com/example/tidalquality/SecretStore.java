package com.example.tidalquality;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypts the client secret using a key bound to Android Keystore. */
public class SecretStore {
    private final SharedPreferences prefs;
    private static final String ALIAS="TidalQualityExplorerKeyV1";
    public SecretStore(Context ctx) { prefs=ctx.getSharedPreferences("localsettings", Context.MODE_PRIVATE); }
    public String getId() { return prefs.getString("client_id", ""); }
    public String getCountry() { return prefs.getString("country", "AR"); }
    public void save(String id, String secret, String country) throws Exception {
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv=c.getIV();
        byte[] ciphertext=c.doFinal(secret.getBytes(StandardCharsets.UTF_8));
        prefs.edit().putString("client_id",id.trim()).putString("country",country.trim().toUpperCase())
             .putString("secret_iv", Base64.encodeToString(iv,Base64.NO_WRAP))
             .putString("secret_blob",Base64.encodeToString(ciphertext,Base64.NO_WRAP)).apply();
    }
    public String getSecret() {
        try {
            String iv=prefs.getString("secret_iv", "");
            String data=prefs.getString("secret_blob", "");
            if (iv.isEmpty()||data.isEmpty())return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128, Base64.decode(iv,Base64.DEFAULT)));
            return new String(c.doFinal(Base64.decode(data,Base64.DEFAULT)), StandardCharsets.UTF_8);
        } catch (Exception e) {return "";}
    }
    private static SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if (ks.containsAlias(ALIAS))return ((KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
        return kg.generateKey();
    }
}
