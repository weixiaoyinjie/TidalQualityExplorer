package com.example.tidalquality;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import android.util.Base64;

/** Public TIDAL catalog only. No playback stream extraction. */
public class TidalClient {
    private String clientId;
    private String clientSecret;
    private String country;
    private String token = "";
    private long tokenExpiresAt = 0;
    private static final String ROOT = "https://openapi.tidal.com/v2";

    public TidalClient(String id, String secret, String countryCode) {
        this.clientId = id.trim(); this.clientSecret = secret;
        this.country = countryCode.trim().toUpperCase(Locale.ROOT);
        if (!this.country.matches("[A-Z]{2}")) this.country = "AR";
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    private static JSONObject fetch(String url, String method, String authorization, String post) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(14000); c.setReadTimeout(18000);
        c.setRequestProperty("Accept", "application/vnd.api+json, application/json");
        c.setRequestProperty("User-Agent", "TidalQualityExplorer/1.0 (Android; personal catalog tool)");
        if (!authorization.isEmpty()) c.setRequestProperty("Authorization", authorization);
        if (post != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            try (OutputStream out = c.getOutputStream()) { out.write(post.getBytes(StandardCharsets.UTF_8)); }
        }
        int status = c.getResponseCode();
        try (InputStream input = status >= 400 ? c.getErrorStream() : c.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (input != null) {
                byte[] buf = new byte[8192]; int n;
                while ((n = input.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > 2500000) throw new Exception("API response too large");
                }
            }
            String body = out.toString(StandardCharsets.UTF_8);
            if (status >= 400) {
                String hint = status == 400 ? "请求参数不匹配，请检查开发者权限/地区" : status == 401 ? "密钥或授权无效" : status == 429 ? "触发 TIDAL API 限流，稍后重试" : "接口返回错误";
                throw new Exception("HTTP " + status + "：" + hint + "\n" + body.substring(0, Math.min(260, body.length())));
            }
            return new JSONObject(body);
        } finally { c.disconnect(); }
    }

    public void ensureAuth() throws Exception {
        if (!token.isEmpty() && System.currentTimeMillis() < tokenExpiresAt) return;
        if (clientId.isEmpty() || clientSecret.isEmpty()) throw new Exception("请先在 API 设置填写开发者 Client ID / Secret");
        String b64 = Base64.encodeToString((clientId + ":" + clientSecret).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        JSONObject json = fetch("https://auth.tidal.com/v1/oauth2/token", "POST", "Basic " + b64, "grant_type=client_credentials");
        token = json.optString("access_token", "");
        if (token.isEmpty()) throw new Exception("Token 响应缺少 access_token");
        tokenExpiresAt = System.currentTimeMillis() + Math.max(90, json.optInt("expires_in", 3600) - 120) * 1000L;
    }

    private JSONObject get(String path) throws Exception {
        ensureAuth();
        String url = path.startsWith("https://") ? path : ROOT + path;
        if (!url.startsWith(ROOT + "/")) throw new Exception("不允许跨域 API 请求");
        return fetch(url, "GET", "Bearer " + token, null);
    }

    public List<MediaEntry> search(String query) throws Exception {
        String base = "/searchResults?filter%5Bquery%5D=" + enc(query)
                + "&countryCode=" + enc(country);
        JSONObject json;
        try {
            json = get(base + "&include=artists.profileArt,albums.coverArt,tracks.artists,tracks.albums.coverArt");
        } catch (Exception ex) {
            if (!ex.getMessage().startsWith("HTTP 400")) throw ex;
            // Some developer tiers or API revisions reject nested includes.
            json = get(base + "&include=artists,albums,tracks");
        }
        return parse(json, null);
    }

    public List<MediaEntry> albumTracks(String id) throws Exception {
        if (!id.matches("[A-Za-z0-9_-]+")) throw new Exception("无效专辑 ID");
        JSONObject json = get("/albums/" + enc(id) + "/relationships/items?countryCode=" + enc(country) + "&include=items");
        return parse(json, "tracks");
    }

    public List<MediaEntry> artistAlbums(String id) throws Exception {
        if (!id.matches("[A-Za-z0-9_-]+")) throw new Exception("无效歌手 ID");
        JSONObject json = get("/artists/" + enc(id) + "/relationships/albums?countryCode=" + enc(country) + "&include=albums");
        return parse(json, "albums");
    }

    public MediaEntry loadDetails(MediaEntry e) throws Exception {
        // Optional album artwork/metadata request, retaining the original entry on unsupported includes.
        if (!"albums".equals(e.type)) return e;
        JSONObject json = get("/albums/" + enc(e.id) + "?countryCode=" + enc(country) + "&include=coverArt,artists");
        List<MediaEntry> items = parse(json, "albums");
        for (MediaEntry v : items) if (v.id.equals(e.id)) return v;
        return e;
    }

    public static class MediaEntry {
        public String id = "", type = "", title = "", subtitle = "", artUrl = "", detail = "";
        public String quality = "音质待确认";
        public int rank = 0;
        public boolean atmos = false;
        public boolean verifiedFormat = false;
        public String year = "";
        public String link() {
            String cat = type.equals("tracks") ? "track" : type.equals("albums") ? "album" : "artist";
            return "https://tidal.com/browse/" + cat + "/" + id;
        }
    }

    public static List<MediaEntry> parse(JSONObject json, String onlyType) {
        Map<String, JSONObject> included = new HashMap<>();
        JSONArray extras = json.optJSONArray("included");
        if (extras != null) for (int i = 0; i < extras.length(); i++) {
            JSONObject o = extras.optJSONObject(i);
            if (o != null) included.put(o.optString("type") + ":" + o.optString("id"), o);
        }
        JSONArray main = json.optJSONArray("data");
        if (main == null) {
            JSONObject one = json.optJSONObject("data");
            main = new JSONArray(); if (one != null) main.put(one);
        }
        List<JSONObject> candidates = new ArrayList<>();
        for (int i=0;i<main.length();i++) {
            JSONObject o = main.optJSONObject(i);
            if (o!=null) candidates.add(o);
        }
        // Search results have a 'searchResults' envelope; music entities are in 'included'.
        if (!included.isEmpty()) candidates.addAll(included.values());
        Set<String> seen = new HashSet<>();
        List<MediaEntry> result = new ArrayList<>();
        for (JSONObject node : candidates) {
            String type = node.optString("type");
            if (!type.equals("artists") && !type.equals("albums") && !type.equals("tracks")) continue;
            if (onlyType!=null && !onlyType.equals(type)) continue;
            String id = node.optString("id");
            if (id.isEmpty() || !seen.add(type+":"+id)) continue;
            JSONObject attrs = node.optJSONObject("attributes");
            if (attrs == null || attrs.length() == 0) continue; // do not show bare linkage IDs
            MediaEntry e = new MediaEntry(); e.id = id; e.type = type;
            e.title = attrs.optString(type.equals("artists") ? "name" : "title", "未命名");
            if (e.title.isEmpty()) e.title = "未命名";
            String date = attrs.optString("releaseDate", "");
            if (date.length()>=4) e.year = date.substring(0,4);
            e.detail = e.year;
            e.subtitle = relatedName(node, included, "artists");
            if (type.equals("artists")) e.subtitle = "歌手";
            if (type.equals("albums") && e.subtitle.isEmpty()) e.subtitle = "专辑";
            if (type.equals("tracks") && e.subtitle.isEmpty()) e.subtitle = "歌曲";
            e.artUrl = artwork(node, included);
            quality(attrs, e);
            result.add(e);
        }
        // stable group ordering: artists > albums > tracks, keep incoming order within each group
        result.sort((a,b) -> Integer.compare(group(a.type),group(b.type)));
        return result;
    }

    private static int group(String t) { return t.equals("artists")?0:t.equals("albums")?1:2; }
    private static String relatedName(JSONObject node, Map<String, JSONObject> included, String rel) {
        JSONObject rs = node.optJSONObject("relationships");
        if (rs==null) return "";
        JSONObject r = rs.optJSONObject(rel);
        if (r==null) return "";
        Object d = r.opt("data");
        JSONObject v = d instanceof JSONArray ? ((JSONArray)d).optJSONObject(0) : d instanceof JSONObject ? (JSONObject)d : null;
        if (v==null) return "";
        JSONObject full = included.get(v.optString("type") + ":" + v.optString("id"));
        return full==null ? "" : full.optJSONObject("attributes")!=null ? full.optJSONObject("attributes").optString("name","") : "";
    }
    private static String artwork(JSONObject node, Map<String, JSONObject> included) {
        JSONObject attrs = node.optJSONObject("attributes");
        if (attrs == null) return "";
        for (String k : new String[]{"cover", "image", "picture"}) {
            String raw = attrs.optString(k, "");
            if (raw.matches("(?i)[0-9a-f]{8}-[0-9a-f-]{27,}")) return "https://resources.tidal.com/images/" + raw.replace('-', '/') + "/320x320.jpg";
        }
        JSONObject rs = node.optJSONObject("relationships");
        if (rs == null) return "";
        for (String key : new String[]{"coverArt", "profileArt", "albums"}) {
            JSONObject rel = rs.optJSONObject(key);
            if (rel == null) continue;
            Object raw = rel.opt("data");
            JSONObject link = raw instanceof JSONArray ? ((JSONArray)raw).optJSONObject(0) : raw instanceof JSONObject ? (JSONObject)raw : null;
            if (link == null) continue;
            JSONObject obj = included.get(link.optString("type") + ":" + link.optString("id"));
            if (obj == null) continue;
            if (key.equals("albums")) return artwork(obj, included);
            JSONObject a = obj.optJSONObject("attributes");
            if (a == null) continue;
            String direct = a.optString("url", a.optString("uri",""));
            if (direct.startsWith("https://")) return direct;
            JSONArray files = a.optJSONArray("files");
            if (files != null) for (int i=0;i<files.length();i++) {
                JSONObject file = files.optJSONObject(i);
                if (file != null) {
                    String uri = file.optString("href", file.optString("url", ""));
                    if (uri.startsWith("https://")) return uri;
                }
            }
        }
        return "";
    }

    private static void quality(JSONObject a, MediaEntry e) {
        if (e.type.equals("artists")) {e.quality="";return;}
        StringBuilder tags = new StringBuilder();
        for (String k : new String[]{"mediaTags", "audioModes", "audioMode", "audioQuality", "quality", "tags"}) {
            Object v = a.opt(k);
            if (v!=null && v!=JSONObject.NULL) tags.append(v).append(' ');
        }
        String q = tags.toString().toUpperCase(Locale.ROOT);
        if (q.contains("DOLBY_ATMOS") || q.contains("DOLBY ATMOS")) {
            e.atmos=true; e.quality="Dolby Atmos · 已标记"; e.rank=600; e.verifiedFormat=true; return;
        }
        int depth = a.optInt("bitDepth", 0);
        int hz = a.optInt("sampleRate", 0);
        if (hz == 0) hz = a.optInt("sampleRateHz", 0);
        if (depth > 0 && hz > 0) {
            e.quality = (depth>=24?"Hi-Res · ":"无损规格待核对 · ") + depth + " bit / " + prettyHz(hz) + " kHz";
            e.rank = (depth >= 24 ? 4000000 : 2000000) + hz;
            e.verifiedFormat = true; return;
        }
        if (q.contains("HIRES_LOSSLESS") || q.contains("HI_RES_LOSSLESS") || q.contains("HI_RES")) {
            e.quality="Hi-Res FLAC · 具体规格待确认"; e.rank=3000000; e.verifiedFormat=true; return;
        }
        if (q.contains("LOSSLESS") || q.contains("FLAC")) {
            e.quality="无损 FLAC · 具体规格待确认"; e.rank=1500000; e.verifiedFormat=true; return;
        }
        if (q.contains("AAC") || q.contains("HIGH") || q.contains("LOW")) {
            e.quality="有损音频 · 码率待确认";e.rank=300000;e.verifiedFormat=true;
        }
    }
    private static String prettyHz(int hz) {
        return String.format(Locale.ROOT, hz%1000==0 ? "%.0f" : "%.1f", hz / 1000.0);
    }
}
