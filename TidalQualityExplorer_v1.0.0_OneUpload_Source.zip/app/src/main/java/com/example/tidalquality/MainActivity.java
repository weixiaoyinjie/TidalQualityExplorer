package com.example.tidalquality;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import org.json.JSONObject;
import org.json.JSONArray;
import java.util.LinkedHashMap;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(9,14,22), PANEL=Color.rgb(24,32,44), MUTED=Color.rgb(149,163,181), WHITE=Color.rgb(244,249,252), TEAL=Color.rgb(82,222,204);
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Map<String,Bitmap> coverCache = Collections.synchronizedMap(new HashMap<>());
    private SecretStore secrets;
    private TidalClient api;
    private final Map<String,TidalClient.MediaEntry> favorites = new LinkedHashMap<>();
    private EditText searchText;
    private TextView status;
    private LinearLayout results, filterBar;
    private List<TidalClient.MediaEntry> current = new ArrayList<>();
    private String filter="全部", activeQuery="", screen="搜索";
    private boolean desc=true;
    private int searchSequence=0;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        secrets=new SecretStore(this); reclient(); loadFavorites();
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        buildScreen();
        if (secrets.getId().isEmpty() || secrets.getSecret().isEmpty()) {
            status.setText("请点击 API 设置，填写 TIDAL Developer 的 Client ID 与 Secret");
        }
    }

    private int dp(float x) {return (int)(getResources().getDisplayMetrics().density*x+0.5f);}
    private GradientDrawable bg(int color,int radius,int strokeColor) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));
        if(strokeColor!=0)g.setStroke(dp(1),strokeColor);
        return g;
    }
    private TextView text(String txt,int sp,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(txt);t.setTextSize(sp);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private LinearLayout vertical() {LinearLayout ll=new LinearLayout(this);ll.setOrientation(1);return ll;}
    private LinearLayout horizontal() {LinearLayout ll=new LinearLayout(this);ll.setOrientation(0);ll.setGravity(Gravity.CENTER_VERTICAL);return ll;}
    private LinearLayout.LayoutParams lp(int w,int h) {return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout ll,int h){ll.addView(new View(this),lp(1,h));}
    private TextView action(String title,boolean primary,Runnable run) {
        TextView b=text(title,13,primary?BG:WHITE,true);
        b.setGravity(Gravity.CENTER);b.setPadding(dp(13),dp(10),dp(13),dp(10));
        b.setBackground(bg(primary?TEAL:PANEL,13,primary?0:Color.rgb(54,68,81)));
        b.setOnClickListener(v->run.run()); return b;
    }
    private void reclient() {api=new TidalClient(secrets.getId(),secrets.getSecret(),secrets.getCountry());}
    private void buildScreen() {
        LinearLayout root=vertical();root.setBackgroundColor(BG);
        root.setPadding(dp(16),dp(14),dp(16),dp(8));
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets sys=insets.getInsets(android.view.WindowInsets.Type.statusBars()|android.view.WindowInsets.Type.navigationBars());
                v.setPadding(dp(16),sys.top+dp(12),dp(16),sys.bottom+dp(6));return insets;
            });
        }
        setContentView(root);
        LinearLayout top=horizontal();
        LinearLayout heading=vertical();heading.addView(text("TIDAL  音质探索",24,WHITE,true));
        TextView mini=text("中文歌手  ·  专辑  ·  音质分级  ·  Atmos",11,MUTED,false);heading.addView(mini);
        top.addView(heading,new LinearLayout.LayoutParams(0,-2,1));
        TextView fav=action("★ 收藏",false,()->{
            ++searchSequence;filter="全部";buildFilters();
            showList("我的收藏","本地收藏 · "+favorites.size()+" 项（不会写入 TIDAL 账户）",new ArrayList<>(favorites.values()));
        });
        LinearLayout.LayoutParams f=lp(-2,-2);f.rightMargin=dp(7);top.addView(fav,f);
        top.addView(action("API 设置",false,this::settings),lp(-2,-2));
        root.addView(top,lp(-1,-2));gap(root,18);

        LinearLayout find=horizontal();find.setPadding(dp(8),dp(5),dp(5),dp(5));find.setBackground(bg(PANEL,16,Color.rgb(55,70,84)));
        searchText=new EditText(this);searchText.setSingleLine(true);searchText.setTextSize(16);searchText.setTextColor(WHITE);
        searchText.setHintTextColor(MUTED);searchText.setHint("歌手 / 专辑 / 歌曲（支持中文）");
        searchText.setBackgroundColor(Color.TRANSPARENT); searchText.setPadding(dp(6),0,dp(4),0);
        find.addView(searchText,new LinearLayout.LayoutParams(0,dp(46),1));
        find.addView(action("搜索",true,this::performSearch),lp(-2,-2));
        root.addView(find,lp(-1,-2));gap(root,10);

        LinearLayout hint=horizontal();
        TextView c=text("例如：蔡琴 / 张学友 / Teresa Teng",12,MUTED,false);
        hint.addView(c,new LinearLayout.LayoutParams(0,-2,1));
        hint.addView(action("排序 ⇅",false,()->{desc=!desc;render();}),lp(-2,-2));
        root.addView(hint);gap(root,12);

        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        filterBar=horizontal();
        hs.addView(filterBar);root.addView(hs);buildFilters();gap(root,12);
        status=text("准备就绪。搜索结果来自 TIDAL 官方公开目录。",12,MUTED,false);
        status.setPadding(dp(4),0,dp(4),dp(9));root.addView(status,lp(-1,-2));

        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        results=vertical();results.setPadding(0,0,0,dp(48));scroll.addView(results);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        render();
    }
    private void buildFilters() {
        filterBar.removeAllViews();
        String[] all={"全部","Hi-Res","无损 FLAC","有损","Dolby Atmos","音质待确认"};
        for(String s:all) {
            boolean selected=s.equals(filter);
            TextView pill=text(s,12,selected?BG:WHITE,selected);
            pill.setBackground(bg(selected?TEAL:PANEL,25,selected?0:Color.rgb(42,57,70)));
            pill.setPadding(dp(14),dp(10),dp(14),dp(10));
            LinearLayout.LayoutParams p=lp(-2,-2);p.rightMargin=dp(7);filterBar.addView(pill,p);
            pill.setOnClickListener(v->{filter=s;buildFilters();render();});
        }
    }
    private void performSearch() {
        final String input=searchText.getText().toString().trim();
        if(input.isEmpty()){toast("请输入歌手名、专辑名或歌曲名");return;}
        if(secrets.getId().isEmpty()||secrets.getSecret().isEmpty()){settings();return;}
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchText.getWindowToken(),0);
        int seq=++searchSequence;screen="搜索";activeQuery=input;status.setText("搜索中："+input+"（中文名称正在解析）");
        results.removeAllViews();results.addView(text("正在查询 MusicBrainz 与 TIDAL…",15,MUTED,false));
        io.execute(()->{
            NameResolver.Resolution resolution=NameResolver.resolve(input);
            String chosen=resolution.chosen;
            try {
                List<TidalClient.MediaEntry> data=api.search(chosen);
                if(data.isEmpty()&&!chosen.equals(input)) {data=api.search(input);chosen=input;}
                final String actual=chosen;
                final List<TidalClient.MediaEntry> found=data;
                runOnUiThread(()->{
                    if(seq!=searchSequence)return;
                    current=found;
                    status.setText("搜索："+input+(actual.equals(input)?"":" → "+actual)+"  ·  "+found.size()+" 条目录结果（非完整曲库）");
                    render();
                    aliasSuggestions(resolution, input);
                });
            } catch(Exception ex) {fail(seq,ex);}
        });
    }
    private void aliasSuggestions(NameResolver.Resolution r,String original) {
        if(r.suggestions.size()<2)return;
        LinearLayout wrap=vertical();wrap.setBackground(bg(PANEL,14,0));wrap.setPadding(dp(11),dp(9),dp(11),dp(9));
        wrap.addView(text("国际艺名候选（点选可重新搜索）",12,MUTED,true));gap(wrap,7);
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
        LinearLayout tags=horizontal();
        int added=0;
        for (String s:r.suggestions) {
            if (s.equals(original)||added>=5) continue;
            added++;
            TextView pill=action(s,false,()->{searchText.setText(s);performSearch();});
            LinearLayout.LayoutParams params=lp(-2,-2);params.rightMargin=dp(6);
            tags.addView(pill,params);
        }
        hs.addView(tags);wrap.addView(hs);
        results.addView(wrap,0,lp(-1,-2));
        gapAtTop();
    }
    private void gapAtTop(){View s=new View(this);results.addView(s,0,lp(1,10));}
    private void showList(String title,String sub,List<TidalClient.MediaEntry> entries) {
        current=entries;screen=title;status.setText(sub);render();
    }
    private void explore(TidalClient.MediaEntry entry) {
        if(entry.type.equals("tracks")) {showEntry(entry);return;}
        int seq=++searchSequence;status.setText("正在加载："+entry.title);results.removeAllViews();
        results.addView(text("正在加载专辑 / 歌曲目录…",15,MUTED,false));
        io.execute(()->{
            try {
                List<TidalClient.MediaEntry> list=entry.type.equals("artists")?api.artistAlbums(entry.id):api.albumTracks(entry.id);
                runOnUiThread(()->{if(seq!=searchSequence)return;showList(entry.title,entry.title+" · "+list.size()+" 条当前返回目录结果",list);});
            } catch(Exception ex){fail(seq,ex);}
        });
    }
    private void render() {
        if(results==null)return;
        results.removeAllViews();
        if(current.isEmpty()) {
            LinearLayout hero=vertical();hero.setBackground(bg(PANEL,21,0));hero.setPadding(dp(20),dp(28),dp(20),dp(30));
            hero.addView(text("用中文寻找世界各地的音乐",20,WHITE,true));gap(hero,12);
            hero.addView(text("输入歌手中文名，自动尝试对应的国际艺名，再显示 TIDAL 的歌手、专辑和歌曲。",14,MUTED,false));gap(hero,16);
            hero.addView(text("Dolby Atmos 是独立筛选项；无法通过公开 API 确认音质的条目不会被误标。",13,TEAL,false));
            results.addView(hero,lp(-1,-2));return;
        }
        List<TidalClient.MediaEntry> list=new ArrayList<>();
        for(TidalClient.MediaEntry e:current) if(match(e))list.add(e);
        list.sort((a,b)->{
            int aGroup=group(a.type),bGroup=group(b.type);
            if(aGroup!=bGroup)return Integer.compare(aGroup,bGroup);
            int val=Integer.compare(a.rank,b.rank);return desc?-val:val;
        });
        if(list.isEmpty()) {
            LinearLayout box=vertical();box.setPadding(dp(20),dp(20),dp(20),dp(20));box.setBackground(bg(PANEL,18,0));
            box.addView(text("当前筛选没有已确认的结果",17,WHITE,true));gap(box,8);
            box.addView(text("公开目录未必包含 Atmos、位深或采样率字段。结果为空不代表 TIDAL 没有这种音乐。切换“全部”或“音质待确认”可查看原始搜索结果。",13,MUTED,false));
            results.addView(box);return;
        }
        String last="";
        for(TidalClient.MediaEntry e:list) {
            String group=e.type.equals("artists")?"歌手":e.type.equals("albums")?"专辑":"歌曲";
            if(!group.equals(last)) {
                TextView header=text(group+"  ·  "+count(list,e.type),15,TEAL,true);
                header.setPadding(dp(2),dp(14),dp(2),dp(10));results.addView(header);last=group;
            }
            addCard(e);
        }
        TextView foot=text("说明：按当前查询返回的记录排序，不代表搜索了 TIDAL 全部版本。播放设备请在 TIDAL 官方 App 中选择。",11,MUTED,false);
        foot.setPadding(dp(6),dp(20),dp(6),dp(8));results.addView(foot);
    }
    private int count(List<TidalClient.MediaEntry> list,String type){int n=0;for(TidalClient.MediaEntry x:list)if(type.equals(x.type))n++;return n;}
    private int group(String x){return x.equals("artists")?0:x.equals("albums")?1:2;}
    private boolean match(TidalClient.MediaEntry e) {
        if(e.type.equals("artists"))return filter.equals("全部");
        switch(filter) {
            case "Hi-Res":return e.quality.startsWith("Hi-Res");
            case "无损 FLAC":return e.quality.contains("FLAC") && !e.atmos;
            case "有损":return e.quality.startsWith("有损");
            case "Dolby Atmos":return e.atmos;
            case "音质待确认":return !e.verifiedFormat;
            default:return true;
        }
    }
    private void addCard(TidalClient.MediaEntry e) {
        LinearLayout row=horizontal();row.setGravity(Gravity.TOP);
        row.setPadding(dp(11),dp(12),dp(10),dp(12));
        row.setBackground(bg(PANEL,16,Color.rgb(36,49,64)));
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);results.addView(row,p);
        FrameLayout artFrame=new FrameLayout(this);
        artFrame.setBackground(bg(Color.rgb(37,57,70),13,0));
        TextView mark=text(e.type.equals("artists")?"♪":e.type.equals("albums")?"♫":"▶",25,TEAL,true);
        mark.setGravity(Gravity.CENTER);artFrame.addView(mark,new FrameLayout.LayoutParams(-1,-1));
        if(e.artUrl.startsWith("https://")) {
            ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            artFrame.addView(img,new FrameLayout.LayoutParams(-1,-1));
            loadCover(img,e.artUrl);
        }
        row.addView(artFrame,lp(80,80));
        LinearLayout textCol=vertical();textCol.setPadding(dp(11),0,0,0);
        row.addView(textCol,new LinearLayout.LayoutParams(0,-2,1));
        TextView title=text(e.title,15,WHITE,true);title.setMaxLines(2);title.setEllipsize(android.text.TextUtils.TruncateAt.END);textCol.addView(title);
        TextView sub=text(e.subtitle+(e.year.isEmpty()?"":" · "+e.year),12,MUTED,false);
        sub.setMaxLines(1);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);textCol.addView(sub);
        gap(textCol,5);
        if(!e.quality.isEmpty()){
            int color=e.atmos?Color.rgb(235,195,118):e.verifiedFormat?TEAL:MUTED;
            textCol.addView(text(e.quality,11,color,false));gap(textCol,7);
        }
        LinearLayout actions=horizontal();
        if(!e.type.equals("tracks")) {
            TextView explore=action(e.type.equals("artists")?"查看专辑":"查看曲目",true,()->explore(e));
            actions.addView(explore);
            View sp=new View(this);actions.addView(sp,lp(6,1));
        }
        TextView open=action("TIDAL ↗",false,()->openTidal(e));actions.addView(open);
        View sp2=new View(this);actions.addView(sp2,lp(6,1));
        actions.addView(action(favorites.containsKey(e.type+":"+e.id)?"★":"☆",false,()->toggleFavorite(e)));
        textCol.addView(actions);
        row.setOnLongClickListener(v->{showEntry(e);return true;});
    }
    private void loadCover(ImageView image,String url) {
        Bitmap fromCache=coverCache.get(url);if(fromCache!=null){image.setImageBitmap(fromCache);return;}
        io.execute(()->{
            try {
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(5000);c.setReadTimeout(9000);
                try(java.io.InputStream in=c.getInputStream()) {
                    Bitmap b=BitmapFactory.decodeStream(in);
                    if(b!=null){coverCache.put(url,b);runOnUiThread(()->image.setImageBitmap(b));}
                }finally{c.disconnect();}
            }catch(Exception ignored) {}
        });
    }
    private void showEntry(TidalClient.MediaEntry e){
        new AlertDialog.Builder(this).setTitle(e.title)
                .setMessage(e.subtitle+"\n"+e.quality+"\n"+e.link())
                .setPositiveButton("打开 TIDAL",(d,w)->openTidal(e))
                .setNeutralButton("复制链接",(d,w)->copy(e.link()))
                .setNegativeButton("关闭",null).show();
    }
    private void openTidal(TidalClient.MediaEntry e) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(e.link()))); }
        catch(Exception ex){copy(e.link());toast("没有找到可打开的浏览器，已复制链接");}
    }
    private void copy(String s){((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("TIDAL",s));toast("已复制链接");}
    private void fail(int seq,Exception err){runOnUiThread(()->{
        if(seq!=searchSequence)return;
        status.setText("请求失败："+err.getMessage());
        results.removeAllViews();
        TextView t=text("无法完成查询\n\n"+err.getMessage()+"\n\n请检查 API 凭据、地区代码和网络。",14,WHITE,false);
        t.setPadding(dp(18),dp(20),dp(18),dp(20));t.setBackground(bg(PANEL,14,0));results.addView(t);
    });}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    private void toggleFavorite(TidalClient.MediaEntry e) {
        String key=e.type+":"+e.id;
        if (favorites.containsKey(key)) {favorites.remove(key);toast("已取消收藏");}
        else {favorites.put(key,e);toast("已收藏到本机");}
        saveFavorites();
        if (screen.equals("我的收藏")) current=new ArrayList<>(favorites.values());
        render();
    }
    private void saveFavorites() {
        JSONArray arr=new JSONArray();
        for (TidalClient.MediaEntry e:favorites.values()) {
            try {
                JSONObject o=new JSONObject();
                o.put("id",e.id);o.put("type",e.type);o.put("title",e.title);
                o.put("subtitle",e.subtitle);o.put("year",e.year);o.put("art",e.artUrl);
                o.put("quality",e.quality);o.put("rank",e.rank);o.put("atmos",e.atmos);
                o.put("verified",e.verifiedFormat);arr.put(o);
            } catch(Exception ignored) {}
        }
        getSharedPreferences("favorites",MODE_PRIVATE).edit().putString("items",arr.toString()).apply();
    }
    private void loadFavorites() {
        try {
            String raw=getSharedPreferences("favorites",MODE_PRIVATE).getString("items","[]");
            JSONArray arr=new JSONArray(raw);
            for(int i=0;i<arr.length();i++) {
                JSONObject o=arr.optJSONObject(i);if(o==null)continue;
                TidalClient.MediaEntry e=new TidalClient.MediaEntry();
                e.id=o.optString("id");e.type=o.optString("type");e.title=o.optString("title");
                e.subtitle=o.optString("subtitle");e.year=o.optString("year");e.artUrl=o.optString("art");
                e.quality=o.optString("quality","音质待确认");e.rank=o.optInt("rank");
                e.atmos=o.optBoolean("atmos");e.verifiedFormat=o.optBoolean("verified");
                if(!e.id.isEmpty()&&!e.type.isEmpty())favorites.put(e.type+":"+e.id,e);
            }
        } catch(Exception ignored) {}
    }

    private void settings() {
        LinearLayout form=vertical();form.setPadding(dp(20),dp(8),dp(20),0);
        EditText id=new EditText(this);id.setSingleLine(true);id.setTextSize(15);id.setHint("Client ID");id.setText(secrets.getId());
        EditText secret=new EditText(this);secret.setSingleLine(true);secret.setTextSize(15);
        secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        secret.setHint("Client Secret（仅保存在手机）");secret.setText(secrets.getSecret());
        EditText country=new EditText(this);country.setSingleLine(true);country.setTextSize(15);country.setHint("地区代码 AR / US");country.setText(secrets.getCountry());
        form.addView(text("TIDAL Developer Client ID",12,MUTED,false));form.addView(id);gap(form,10);
        form.addView(text("TIDAL Developer Client Secret",12,MUTED,false));form.addView(secret);gap(form,10);
        form.addView(text("曲库地区（ISO 两位代码）",12,MUTED,false));form.addView(country);gap(form,12);
        form.addView(text("本版使用公开目录查询授权，不会读取你的 TIDAL 密码，也不能远程控制音响。",12,MUTED,false));
        new AlertDialog.Builder(this).setTitle("TIDAL API 设置")
                .setView(form)
                .setNegativeButton("取消",null)
                .setNeutralButton("开发者平台",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://developer.tidal.com/"))))
                .setPositiveButton("保存并测试",(d,w)->{
                    String cc=country.getText().toString().trim().toUpperCase();
                    if(!cc.matches("[A-Z]{2}")){toast("地区代码必须是两个字母，如 AR");return;}
                    try {
                        secrets.save(id.getText().toString(),secret.getText().toString(),cc);
                        reclient();status.setText("正在验证 TIDAL API 授权…");
                        io.execute(()->{
                            try {api.ensureAuth();runOnUiThread(()->status.setText("TIDAL API 已连接。输入中文歌手开始搜索。"));}
                            catch(Exception ex){runOnUiThread(()->status.setText("API 测试失败："+ex.getMessage()));}
                        });
                    } catch(Exception ex) {toast("无法安全保存凭据："+ex.getMessage());}
                }).show();
    }
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
