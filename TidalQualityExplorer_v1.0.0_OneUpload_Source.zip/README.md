# TIDAL 音质探索 v1.0.0 — GitHub OneUpload

**功能**：TIDAL 官方公开目录搜索；中文艺名→国际名（本地词库+MusicBrainz）；歌手/专辑/曲目；按已确认的音质规格排序；独立 Atmos 筛选；本地收藏；打开官方 TIDAL 页面；复制链接。无 DRM 流提取、无私有接口。

## 编译（无需本地电脑）
1. GitHub 创建空 Public 或 Private 仓库 `TidalQualityExplorer`。
2. **两种方法任选**：A. 解压 ZIP，把其中全部文件上传仓库根目录（包含隐藏目录 `.github`）；B. 把 ZIP **原样**上传仓库根目录，并在 GitHub → `Add file → Create new file` 创建 `.github/workflows/build-apk.yml`，把随项目提供的同名编译代码复制进去。工作流会自动解压 ZIP。
3. 打开 GitHub → Actions → `Build TIDAL Quality Explorer APK` → `Run workflow`（或 Push 自动运行）。
4. 成功后下载 Artifact `TidalQualityExplorer-v1.0.0-debug-apk`，解压取得 `app-debug.apk`，安装 Fold6。

## 首次配置
TIDAL 目录 API 必须先获得开发者凭据。前往 https://developer.tidal.com/ 注册 App，获得自己的 **Client ID 和 Client Secret**。在本 App 中点击「API 设置」输入（只在本机加密存储，**不要提交到 GitHub**）。选择国家代码：阿根廷 `AR`；也可改为 `US` 等测试地区，曲库受地区影响。点击「测试连接」验证。

> 仅针对**个人自用/研究验证**：移动客户端持有 Client Secret 无法从根本上杜绝提取，不能作为正式发行版架构。若要分发，应改为官方 OAuth 授权码+PKCE 或由私有后端保存 client secret。本版本使用官方 `client_credentials` 目录查询，不具备更改你 TIDAL 账户歌单的权限，也无需 TIDAL 用户密码。

## 关于 Atmos 与音质
TIDAL 正式公开目录接口不保证返回 bitDepth、sampleRate、audioMode 等全部播放规格，因此 App **从不猜测**。只有接口确切返回相应字段或 Atmos 标签时才列入已确认筛选结果；其余标为「音质待确认」。不会用低等级格式假装成 CD 或 Hi-Res。

* Atmos 为独立特殊筛选，不参与立体声 FLAC 排名。
* 已知立体声采样率/位深按位深、采样率降序显示；只有品质标签但无数字时只显示档位，不虚构 24/192。
* TIDAL 官方 App 实际播放格式可能因设备与网络不同而变化。
* 点击条目打开官方 TIDAL 页面，用户自行在官方 App 中选择已经支持播放的 S61B 或 Google TV；本应用**不提供**远程 TIDAL Connect 命令、不解码音乐、无歌单写入。

## APIs 与许可
* TIDAL API: `https://openapi.tidal.com/v2/searchResults?filter[query]=...` （2026 新接口）。`https://auth.tidal.com/v1/oauth2/token`。TIDAL Developer Portal Terms 适用。
* MusicBrainz: `https://musicbrainz.org/ws/2/artist/?query=...&fmt=json`，遵循 MusicBrainz 请求速率和署名条款。
* 列表按当前查询返回的记录排序，非 TIDAL 全平台穷举；搜索条件/区域可能影响覆盖率。

## 已知局限
1. 公开目录权限与字段会变化，出现 400/401/429 会有错误提示；可能需要在 TIDAL 后台申请权限。
2. 没有实机 Android SDK 编译环境，本 ZIP 提供完整 GitHub Actions 构建流程，但 **未在本环境真正运行 Gradle/安装实测**。
3. 某些专辑封面缺少公开可用 URL 时显示占位。
4. 当前不包含用户播放列表写入、设备远控、完整位深采样率覆盖，计划后续验证后迭代。
