package com.example.tidalquality;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONObject;

public class NameResolver {
    private static final Map<String,String> LOCAL = new HashMap<>();
    static {
        LOCAL.put("张学友","Jacky Cheung"); LOCAL.put("蔡琴","Tsai Chin");
        LOCAL.put("邓丽君","Teresa Teng"); LOCAL.put("王菲","Faye Wong");
        LOCAL.put("周杰伦","Jay Chou"); LOCAL.put("陈奕迅","Eason Chan");
        LOCAL.put("林忆莲","Sandy Lam"); LOCAL.put("刘德华","Andy Lau");
        LOCAL.put("张国荣","Leslie Cheung"); LOCAL.put("梅艳芳","Anita Mui");
        LOCAL.put("孙燕姿","Stefanie Sun"); LOCAL.put("梁静茹","Fish Leong");
        LOCAL.put("李宗盛","Jonathan Lee"); LOCAL.put("莫文蔚","Karen Mok");
        LOCAL.put("张惠妹","A-Mei"); LOCAL.put("罗大佑","Lo Ta-yu");
        LOCAL.put("李荣浩","Ronghao Li"); LOCAL.put("田馥甄","Hebe Tien");
    }
    public static class Resolution {
        public String chosen;
        public List<String> suggestions = new ArrayList<>();
    }
    public static Resolution resolve(String query) {
        Resolution result = new Resolution();
        result.chosen = query;
        LinkedHashSet<String> suggestions = new LinkedHashSet<>();
        suggestions.add(query);
        if (LOCAL.containsKey(query)) suggestions.add(LOCAL.get(query));
        if (containsHan(query)) {
            try {
                String url = "https://musicbrainz.org/ws/2/artist/?query=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                        + "&fmt=json&limit=5";
                HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
                c.setConnectTimeout(8000); c.setReadTimeout(9000);
                c.setRequestProperty("User-Agent", "TidalQualityExplorer/1.0 (personal use; help: https://developer.tidal.com)");
                try (InputStream in=c.getInputStream()) {
                    ByteArrayOutputStream buf=new ByteArrayOutputStream();
                    byte[] chunk=new byte[4096];int n;
                    while ((n=in.read(chunk))!=-1) {buf.write(chunk,0,n);if(buf.size()>500000)break;}
                    JSONArray artists=new JSONObject(buf.toString(StandardCharsets.UTF_8)).optJSONArray("artists");
                    if (artists!=null) for (int i=0;i<Math.min(artists.length(),4);i++) {
                        JSONObject a=artists.optJSONObject(i);if(a==null)continue;
                        String name=a.optString("name", "");
                        if (isLatin(name)) suggestions.add(name);
                        JSONArray aliases=a.optJSONArray("aliases");
                        if (aliases!=null) for (int j=0;j<Math.min(aliases.length(),15);j++) {
                            JSONObject alias=aliases.optJSONObject(j);
                            if (alias==null)continue;
                            String v=alias.optString("name", "");
                            if (isLatin(v) && v.length()<70) suggestions.add(v);
                        }
                    }
                } finally {c.disconnect();}
            } catch (Exception ignored) { /* Chinese search and built-in aliases remain available offline */ }
        }
        result.suggestions.addAll(suggestions);
        if (LOCAL.containsKey(query)) result.chosen=LOCAL.get(query);
        else if (containsHan(query)) for (String v : suggestions) if (isLatin(v)) {result.chosen=v;break;}
        return result;
    }
    private static boolean containsHan(String s) { return s.codePoints().anyMatch(cp->Character.UnicodeScript.of(cp)==Character.UnicodeScript.HAN); }
    private static boolean isLatin(String s) {
        if (s==null || s.isBlank())return false;
        if (containsHan(s))return false;
        return s.codePoints().anyMatch(cp -> Character.UnicodeScript.of(cp)==Character.UnicodeScript.LATIN);
    }
}
